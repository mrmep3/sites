const carousel = () => {
	console.log('Hello');
}

export default carousel;